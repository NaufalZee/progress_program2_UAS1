from tkinter import *
from tkinter import ttk
import tkinter as tk
from tkinter import scrolledtext
import data

ws = Tk()
ws.geometry('600x400')
ws.title('Bahasa Indonesia')
ws['bg']='#f2f2f2'

def on_scroll(*args):
    text.yview(*args)

def function(event):
    # create a label and entry * amount entered
    if entry1.get() == "":
        return
    else:
        i = 1
        while i <= int(entry1.get()):
            container_soal = Frame(ws)
            container_soal.grid(row=i+1, column=1)

            label_container = tk.Label(container_soal, text=f"Container {i}")
            label_container.grid(row=i+1, column=1)

            t = Text(container_soal, width = 15, height = 5, wrap = NONE, 
                 yscrollcommand = v.set)
            v = Scrollbar(ws)
            v.pack(side = RIGHT, fill = Y)
            v.config(command=t.yview)

            jawaban = tk.Checkbutton(container_soal, text="a)")
            jawaban.grid(row=i+3, column=1)
            jawaban = tk.Checkbutton(container_soal, text="b)")
            jawaban.grid(row=i+4, column=1)
            jawaban = tk.Checkbutton(container_soal, text="c)")
            jawaban.grid(row=i+5, column=1)

            i = i + 1

ws.bind("<Return>", function)



########labell###############
judul = tk.Label(text="Judul Soal")
judul.grid(row=0, column=0)

entry2 = tk.Entry()
entry2.grid(row=0, column=1)
entry2.focus()

label_amount = tk.Label(text="Jumlah Soal")
label_amount.grid(row=1, column=0)

entry1 = tk.Entry()
entry1.grid(row=1, column=1)
entry1.focus()


#checkbutton##################
text1 = Frame(ws)
text1.grid(row = 2, column=1)

text = scrolledtext.ScrolledText(text1, wrap=tk.WORD, width=30, height=5)
text.pack(expand=True, fill="both")

scrollbar = tk.Scrollbar(text1, command=on_scroll)
scrollbar.pack(side=tk.RIGHT, fill="y")

text.config(yscrollcommand=scrollbar.set)





ws.mainloop()