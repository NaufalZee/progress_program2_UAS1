from tkinter import *
from tkinter import ttk
import tkinter as tk
from tkinter.messagebox import showinfo

ws = Tk()
ws.geometry('600x400')
ws.title('Buat Soal')
ws['bg']='#f2f2f2'

l = tk.Label(ws, bg='#f2f2f2', width=20, text='empty')
l.pack(pady=20)

# create a list box
langs = ('1','2','3')

var = tk.Variable(value=langs)

listbox = tk.Listbox(
    ws,
    listvariable=var,
    height=5,
    selectmode=tk.EXTENDED)

listbox.pack(padx=10,pady=10,expand=True, fill=tk.BOTH, side=tk.LEFT)

# link a scrollbar to a list
scrollbar = ttk.Scrollbar(
    ws,
    orient=tk.VERTICAL,
    command=listbox.yview
)

listbox['yscrollcommand'] = scrollbar.set
scrollbar.pack(side=tk.LEFT, expand=True, fill=tk.Y)

def items_selected(event):
    selected_indices = listbox.curselection()
    selected_langs = ",".join([listbox.get(i) for i in selected_indices])
    msg = f'You selected: {selected_langs}'

    showinfo(title='Information', message=msg)

listbox.bind('<<ListboxSelect>>', items_selected)

def print_selection():
    if (var1.get() == 1) & (var2.get() == 0):
        l.config(text='I love Python ')
    elif (var1.get() == 0) & (var2.get() == 1):
        l.config(text='I love C++')
    elif (var1.get() == 0) & (var2.get() == 0):
        l.config(text='I do not anything')
    else:
        l.config(text='I love both')
 
var1 = tk.IntVar()
var2 = tk.IntVar()

c1 = tk.Checkbutton(ws, text='Python',variable=var1, onvalue=1, offvalue=0, command=print_selection)
c1.pack()
c2 = tk.Checkbutton(ws, text='C++',variable=var2, onvalue=1, offvalue=0, command=print_selection)
c2.pack()

ws.mainloop()