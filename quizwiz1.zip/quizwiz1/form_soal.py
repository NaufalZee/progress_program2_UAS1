from tkinter import *
from tkinter import ttk
from tkinter import messagebox
import data
import tkinter as tk
from tkinter.messagebox import showinfo

ws = tk.Tk()
ws.geometry('600x400')
ws.title('Buat Soal')
ws['bg']='#f2f2f2'

data_jawaban = []
var_values = []
var_soal = []

judul = tk.Label(text="Judul Soal").pack()

entry2 = tk.Entry()
entry2.focus()
entry2.pack()

def buat_checkbutton():
    global var_values
    soal = tk.Entry(ws).pack()

    for i in range(3):
        var = tk.IntVar()
        var_values.append(var)
        tk.Checkbutton(ws, text=chr(i+65), variable=var, onvalue=1, offvalue=0, command=ubah).pack()

def ubah():
    global data_jawaban
    data_jawaban = []
    for var in var_values:
        if var.get() == 1:
            data_jawaban.append(chr(var_values.index(var)+65))
    if len(data_jawaban) == 1:
        messagebox.showinfo('Information', f"Anda memilih jawaban {data_jawaban[0]}")
    else:
        messagebox.showinfo('Information', "Anda tidak memilih jawaban atau memilih lebih dari satu jawaban")

tombol_buatSoal = tk.Button(ws, text="Tambah Soal", command=buat_checkbutton)
tombol_buatSoal.pack()

ws.mainloop()