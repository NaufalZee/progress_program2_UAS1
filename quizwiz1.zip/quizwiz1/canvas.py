import tkinter as tk
from tkinter import messagebox

data_jawaban = []
var_values = []

def buat_checkbutton():
    global var_values
    for i in range(3):
        var = tk.IntVar()
        var_values.append(var)
        tk.Checkbutton(checkbutton_frame, text=chr(i+65), variable=var, onvalue=1, offvalue=0, command=ubah).grid(row=i, column=0, sticky='w')

def ubah():
    global data_jawaban
    data_jawaban = []
    for var in var_values:
        if var.get() == 1:
            data_jawaban.append(chr(var_values.index(var)+65))
    if len(data_jawaban) == 1:
        messagebox.showinfo('Information', f"Anda memilih jawaban {data_jawaban[0]}")
    else:
        messagebox.showinfo('Information', "Anda tidak memilih jawaban atau memilih lebih dari satu jawaban")

root = tk.Tk()

tk.Button(root, text="Buat Checkbutton", command=buat_checkbutton).pack()

checkbutton_frame = tk.Frame(root)
checkbutton_frame.pack(fill='both', expand=True)

checkbutton_canvas = tk.Canvas(checkbutton_frame)
checkbutton_canvas.pack(side='left', fill='both', expand=True)

checkbutton_scrollbar = tk.Scrollbar(checkbutton_frame, orient='vertical', command=checkbutton_canvas.yview)
checkbutton_scrollbar.pack(side='right', fill='y')

checkbutton_canvas.configure(yscrollcommand=checkbutton_scrollbar.set)
checkbutton_canvas.bind('<Configure>', lambda e: checkbutton_canvas.configure(scrollregion=checkbutton_canvas.bbox('all')))

checkbutton_frame = tk.Frame(checkbutton_canvas)
checkbutton_canvas.create_window((0, 0), window=checkbutton_frame, anchor='nw')

root.mainloop()