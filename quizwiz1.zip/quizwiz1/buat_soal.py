from tkinter import *
from tkinter import ttk
import data

ws = Tk()
ws.geometry('600x400')
ws.title('Buat Soal')
ws['bg']='#f2f2f2'

e1 = StringVar()

def sub_create():
    a = e1.get()
    materi = a.lower()
    if (materi == "matematika"):
        ws.destroy()
        import pages_mtk
    elif (materi == "bahasa indonesia"):
        ws.destroy()
        import pages_bin
    elif (materi == "bahasa inggris"):
        ws.destroy()
        import pages_bing
    elif (materi == "penalaran umum"):
        ws.destroy()
        import pages_kpu
    elif (materi == "kuantitatif"):
        ws.destroy()
        import pages_kk
    elif (materi == "pengetahuan umum"):
        ws.destroy()
        import pages_ppu
    elif (materi == "literasi"):
        ws.destroy()
        import pages_kbm

judul = Label(ws, text="BUAT SOALWLEOWLEO")
judul.pack(pady=50)

label1 = ttk.Label(ws, text="Materi:")
label1.pack()

e1 = ttk.Entry(ws)
e1.focus_force()
e1.pack()

submit = Button(ws, text="SUBMIT", command=sub_create)
submit.pack()


ws.mainloop()