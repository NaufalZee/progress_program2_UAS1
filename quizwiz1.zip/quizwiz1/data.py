soal_bin = []
jawaban_bin = []
soal_bing = []
jawaban_bing = []
soal_kbm = []
jawaban_kbm = []
soal_kk = []
jawaban_kk = []
soal_kpu = ["Apabila SEPEDA ditulis menjadi VHSIHE, maka PENSIL juga ditulis menjadi..."]
jawaban_kpu = ['c']
descJawab_kpu = ['SHQVLO','SHQMWP', 'SHQWMO']
soal_mtk = []
jawaban_mtk = []
soal_ppu = []
jawaban_ppu = []

def simpanVar(data1, data2):
    global materi, jumlahSoal
    materi = data1
    jumlahSoal = int(data2)
    bin.append("ww")


