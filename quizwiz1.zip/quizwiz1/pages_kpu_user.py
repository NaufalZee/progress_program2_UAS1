from tkinter import *
from tkinter import ttk
import tkinter as tk
from tkinter import messagebox
from data import *
from tkinter.messagebox import showinfo

ws = Tk()
ws.geometry('600x400')
ws.title('Buat Soal')
ws['bg']='#f2f2f2'

l = tk.Label(ws, bg='#f2f2f2', width=20, text=f"{soal_kpu[0]}")
l.pack(pady=20)

def print_selection():
    if (var1.get() == 1) & (var2.get() == 0):
        l.config(text='I love Python ')
    elif (var1.get() == 0) & (var2.get() == 1):
        l.config(text='I love C++')
    elif (var1.get() == 0) & (var2.get() == 0):
        l.config(text='I do not anything')
    else:
        l.config(text='I love both')
 
var1 = tk.IntVar()
var2 = tk.IntVar()
var3 = tk.IntVar()


c1 = tk.Checkbutton(ws, text=f'a) {descJawab_kpu[0]}',variable=var1, onvalue=1, offvalue=0, command=print_selection)
c1.pack()
c2 = tk.Checkbutton(ws, text=f'b) {descJawab_kpu[1]}',variable=var2, onvalue=1, offvalue=0, command=print_selection)
c2.pack()
c3 = tk.Checkbutton(ws, text=f'c) {descJawab_kpu[2]}',variable=var2, onvalue=1, offvalue=0, command=print_selection)
c2.pack()